package com.jaydeep.pixelarena

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build

class ArenaWidgetProvider : AppWidgetProvider() {
    override fun onEnabled(context: Context) { start(context) }
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { start(context) }
    override fun onDisabled(context: Context) { context.stopService(Intent(context, ArenaAnimationService::class.java)) }
    private fun start(context: Context) {
        val intent = Intent(context, ArenaAnimationService::class.java)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
    }
}
