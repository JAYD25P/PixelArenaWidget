package com.jaydeep.pixelarena

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.graphics.*
import android.os.*
import android.widget.RemoteViews
import kotlin.math.*
import kotlin.random.Random

class ArenaAnimationService : Service() {
    private val handler=Handler(Looper.getMainLooper())
    private lateinit var engine: BattleRenderer
    private val tick=object:Runnable { override fun run() { render(); handler.postDelayed(this,180) } }
    override fun onCreate() { super.onCreate(); createNotification(); engine=BattleRenderer(this); startForeground(41,notification()); handler.post(tick) }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { render(); return START_STICKY }
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(intent:Intent?)=null
    private fun createNotification(){ if(Build.VERSION.SDK_INT>=26){ val nm=getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel("pixel_arena","Pixel Arena animation",NotificationManager.IMPORTANCE_LOW)) } }
    private fun notification()=Notification.Builder(this,if(Build.VERSION.SDK_INT>=26)"pixel_arena" else "").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Pixel Arena is running").setContentText("Hero vs Skullwolf — autonomous widget battle").setOngoing(true).build()
    private fun render(){ val mgr=AppWidgetManager.getInstance(this); val ids=mgr.getAppWidgetIds(ComponentName(this,ArenaWidgetProvider::class.java)); if(ids.isEmpty()){ stopSelf(); return }; val bitmap=engine.frame(560,230); ids.forEach { id -> val rv=RemoteViews(packageName,R.layout.widget_arena); rv.setImageViewBitmap(R.id.battle_image,bitmap); rv.setTextViewText(R.id.battle_status,engine.status()); mgr.updateAppWidget(id,rv) } }
}

private data class Fighter(var x:Float,var hp:Int=100,var vx:Float=0f,var facing:Int=1,var action:String="idle",var actionTicks:Int=0,var cooldown:Int=0,var hitFlash:Int=0)
private class BattleRenderer(private val context:Context) {
    private val heroIdle=load("male_hero_template-idle.png"); private val heroWalk=load("male_hero_template-walk.png"); private val heroRun=load("male_hero_template-run.png"); private val heroJump=load("male_hero_template-jump.png"); private val heroCombo=load("male_hero_template-combo_1.png"); private val heroComboEnd=load("male_hero_template-combo_1_end.png")
    private val wolf=load("skullwolf.png")
    private var hero=Fighter(145f,facing=1); private var beast=Fighter(415f,facing=-1)
    private var elapsed=0; private var lastHeroAction="idle"; private var lastWolfAction="idle"; private var lastHeroAttack=""; private var lastWolfAttack=""; private var statusText="AUTO BATTLE • LIVE"
    private var heroFrame=0; private var wolfFrame=0; private val random=Random(System.nanoTime()); private var heroDir=1; private var wolfDir=-1; private var hitEffects= mutableListOf<Triple<Float,Float,Int>>()
    private fun load(name:String):Bitmap= context.assets.open("sprites/$name").use { BitmapFactory.decodeStream(it) }
    fun status()=statusText
    fun frame(width:Int,height:Int):Bitmap {
        elapsed++; updateFighter(hero,beast,true,width); updateFighter(beast,hero,false,width)
        val bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); val c=Canvas(bmp); c.drawColor(Color.TRANSPARENT,PorterDuff.Mode.CLEAR)
        when(context.getSharedPreferences("arena",0).getString("background","Glass")) {
            "Solid" -> c.drawColor(Color.rgb(22,29,48))
            "Ice" -> { val p=Paint();p.shader=LinearGradient(0f,0f,0f,height.toFloat(),0xCC9DEBFF.toInt(),0xCC203E73.toInt(),Shader.TileMode.CLAMP);c.drawRect(0f,0f,width.toFloat(),height.toFloat(),p) }
            "Glass" -> { val p=Paint();p.color=0x995A7895.toInt();c.drawRoundRect(0f,0f,width.toFloat(),height.toFloat(),18f,18f,p);p.color=0x44FFFFFF;c.drawRect(0f,0f,width.toFloat(),height*.42f,p) }
        }
        val floor=height*.80f
        val line=Paint().apply { color=0x886CDFFF.toInt();strokeWidth=2f };c.drawLine(0f,floor,width.toFloat(),floor,line)
        drawHp(c,14f,12f,hero.hp,0xFF5DE0B0.toInt(),width*.42f);drawHp(c,width*.56f,12f,beast.hp,0xFFFF647D.toInt(),width*.42f)
        drawHero(c,hero,floor);drawWolf(c,beast,floor)
        val ep=Paint(Paint.ANTI_ALIAS_FLAG); val nextEffects=mutableListOf<Triple<Float,Float,Int>>()
        hitEffects.forEach { e -> ep.color=0xFFFFD879.toInt();ep.alpha=(e.third*12).coerceIn(0,255);c.drawCircle(e.first,e.second,(9-e.third/2).coerceAtLeast(2).toFloat(),ep);if(e.third>1)nextEffects.add(e.copy(third=e.third-1)) };hitEffects=nextEffects
        statusText=when {hero.hp<=0->"SKULLWOLF WINS";beast.hp<=0->"HERO WINS";else->"AUTO BATTLE • LIVE"}
        return bmp
    }
    private fun drawHp(c:Canvas,x:Float,y:Float,hp:Int,color:Int,w:Float){val p=Paint(Paint.ANTI_ALIAS_FLAG);p.color=0x88333344.toInt();c.drawRoundRect(x,y,x+w,y+7,4f,4f,p);p.color=color;c.drawRoundRect(x,y,x+w*hp/100f,y+7,4f,4f,p)}
    private fun updateFighter(a:Fighter,b:Fighter,isHero:Boolean,width:Int){
        if(a.hp<=0)return
        a.cooldown--;a.actionTicks++
        val distance=b.x-a.x; val absD=abs(distance); a.facing=if(distance>=0)1 else -1
        if(a.action=="hit"){ if(a.actionTicks>9){a.action="idle";a.actionTicks=0};return }
        if(a.action=="attack"||a.action=="combo"||a.action=="special"){
            if(a.actionTicks==5){if(absD<if(a.action=="special")150 else 105){b.hp=(b.hp-if(a.action=="special")18 else if(a.action=="combo")12 else 7).coerceAtLeast(0);b.action="hit";b.actionTicks=0;b.vx=0f;hitEffects.add(Triple(b.x, if(isHero)width*.48f else width*.48f,8))}}
            if(a.actionTicks>if(a.action=="combo")23 else 17){a.action="idle";a.actionTicks=0;a.cooldown=8};return
        }
        if(a.cooldown<=0 && random.nextFloat()<0.035f){val options=listOf("idle","walk","run","jump","attack","combo","special");var next=options.random(random);if(next==a.action)next=options.filter{it!=a.action}.random(random);a.action=next;a.actionTicks=0}
        if(absD>150 && a.action=="idle" && random.nextFloat()<.04f)a.action="walk"
        when(a.action){"walk"->{a.x+=a.facing*1.6f; if(random.nextFloat()<.025f)a.action="idle"};"run"->{a.x+=a.facing*3.4f;if(random.nextFloat()<.035f)a.action="idle"};"jump"->{a.x+=a.facing*1.2f;if(a.actionTicks>20)a.action="idle"};"idle"->{} }
        a.x=a.x.coerceIn(44f,width-44f)
        if(absD<55 && a.action=="walk")a.action="idle"
    }
    private fun drawHero(c:Canvas,f:Fighter,floor:Float){
        val sheet=when(f.action){"walk"->heroWalk;"run"->heroRun;"jump"->heroJump;"attack","special"->heroCombo;"combo"->heroComboEnd;else->heroIdle}
        val cols=sheet.width/128;val count=cols.coerceAtLeast(1);val index=(f.actionTicks/(if(f.action=="idle")7 else 3))%count
        val src=Rect(index*128,0,(index+1)*128,128);val dest=RectF(f.x-31,floor-91-(if(f.action=="jump")18*sin(f.actionTicks/20f*PI).toFloat().coerceAtLeast(0f) else 0f),f.x+31,floor+5)
        val save=c.save();if(f.facing<0)c.scale(-1f,1f,f.x,floor);val p=Paint().apply{isFilterBitmap=false;alpha=if(f.action=="hit")150 else 255};c.drawBitmap(sheet,src,dest,p);c.restoreToCount(save)
    }
    private fun drawWolf(c:Canvas,f:Fighter,floor:Float){
        val cols=7;val rows=4;val index=(f.actionTicks/5)%6;val src=Rect(index*64,0,index*64+64,64);val dest=RectF(f.x-48,floor-65,f.x+48,floor+5)
        val save=c.save();if(f.facing>0)c.scale(-1f,1f,f.x,floor);val p=Paint().apply{isFilterBitmap=false;alpha=if(f.action=="hit")145 else 255};c.drawBitmap(wolf,src,dest,p);c.restoreToCount(save)
    }
}
