package com.jaydeep.pixelarena

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.widget.*
import android.view.View
import android.view.ViewGroup
import android.content.Intent
import android.os.Build

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("arena", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,36,28,24); setBackgroundColor(0xFF101827.toInt()) }
        root.addView(TextView(this).apply { text="PIXEL ARENA"; textSize=25f; setTextColor(-1); setTypeface(null,1) })
        root.addView(TextView(this).apply { text="Autonomous home-screen battle"; textSize=14f; setTextColor(0xFFB9D4E8.toInt()); setPadding(0,8,0,24) })
        root.addView(TextView(this).apply { text="Widget background"; textSize=17f; setTextColor(-1) })
        val choices = listOf("Ice", "Solid", "Transparent", "Glass")
        val group = RadioGroup(this).apply { orientation=RadioGroup.VERTICAL }
        choices.forEach { choice ->
            val rb=RadioButton(this).apply { text=choice; textSize=16f; setTextColor(-1); id=View.generateViewId(); isChecked=prefs.getString("background","Glass")==choice }
            group.addView(rb); rb.tag=choice
        }
        root.addView(group)
        group.setOnCheckedChangeListener { g, checked ->
            val selected=g.findViewById<RadioButton>(checked)?.tag as? String ?: "Glass"
            prefs.edit().putString("background",selected).apply()
            val i=Intent(this,ArenaAnimationService::class.java); if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
        }
        root.addView(TextView(this).apply { text="Add the Pixel Arena widget from your launcher's Widgets panel. The battle runs automatically; no attack or movement commands are required. The service uses a persistent notification while animating."; textSize=13f; setTextColor(0xFFB9D4E8.toInt()); setPadding(0,28,0,0) })
        setContentView(root)
    }
}
