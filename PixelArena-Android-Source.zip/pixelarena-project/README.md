# Pixel Arena Widget

Android home-screen widget featuring an autonomous pixel-art battle between the supplied Male Hero Template and Skullwolf sprites.

## Features
- Automatic autonomous combat with randomized idle, walk, run, jump, attack, combo and special states.
- Fighters move, face one another, react to hits, respect horizontal widget bounds, and have independent health.
- Ice, Solid, Transparent and Glass widget background modes, configurable from the launcher app.
- Resizable home-screen widget.
- GitHub Actions debug APK build on every push to `main` and via manual workflow dispatch.

## Build
Requires JDK 17 and Gradle 8.9+ (Android Gradle Plugin 8.7.3).

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Install and use
1. Install the APK.
2. Open Pixel Arena and select a widget background.
3. Add Pixel Arena from the Android launcher's Widgets picker.
4. Keep the widget placed on the home screen for the animation service to run.

The app uses a foreground service while the widget is active to keep the animation moving. Android may display a persistent notification. Remove the widget to stop the service.

## Sprite credits and licensing
The supplied sprite archives are included as provided. Review their original license files and source terms before redistribution. The Male Hero archive's license file is retained in `app/src/main/assets/sprites/` only if included by the user; the Skullwolf archive did not include a separate license file.
